﻿<?php
header("Location: https://www.certqcs.com/index-16.htm?sec=page&id=87&title=certified-organisations");
die();
?>